/* Jobs*/
function jobs_body(rows, pageno, sortby, sort_order) 
{
  var qStr = {
    "rows" : rows,
    "pageno" : pageno,
    "sortby" : sortby,
    "sort_order" : sort_order,
    "name" : $("#name").val(),
    "keywords" : $("#keywords").val(),
    "s_department" : $("#s_department").val(),
  };
  $.post(WEB_ROOT+"Jobs/jobs_body", qStr, function (data) {
    $("#jobs_body").html(data);
  });
}

function reset_jobs_body() 
{
  $("#keywords").val("");
  jobs_body(10, 1, 'id', 'asc');
}

function jobs_search(e) 
{
  e.preventDefault();
  jobs_refresh();
}

function jobs_refresh() 
{
  var qStr = {
    "rows" : $("#rows").val(),
    "pageno" : $("#pageno").val(),
    "sortby" : $("#sortby").val(),
    "sort_order" : $("#sort_order").val(),
    "status" : $("#status").val(),
    "name" : $("#name").val(),
    "keywords" : $("#keywords").val(),
    "s_department" : $("#s_department").val(),
  };
  $.post(WEB_ROOT+"Jobs/jobs_body", qStr, function (data) {
    $("#jobs_body").html(data);
  });
}

function job_add()
{
  preLoader();
  $.post(WEB_ROOT+"Jobs/job_add",function (data) {
    loadModal(data);
    closePreLoader();
  });
}

function job_insert(e)
{
  e.preventDefault();
  $('button[type = "submit"]').prop('disabled', true);
  $('button[type = "submit"]').html('<i class="fa fa-spinner fa-spin"></i>&nbsp;<strong>processing...</strong>');
  var params = $("#jobadd_form").serializeArray();
  $.post(WEB_ROOT + "Jobs/job_insert", params, function(data){
    $(".modal-dialog").parent().html(data);
    $('button[type = "submit"]').prop('disabled',false);
    $('button[type = "submit"]').html('<i class="fa fa-pencil-square-o">&nbsp;</i>Update');
    reset_jobs_body(parent);
  });
}

function job_edit(id)
{
  preLoader();
  $.post(WEB_ROOT+"Jobs/job_edit",{"id":id},function (data) {
    loadModal(data);
    closePreLoader();
  });
}

function job_update(e)
{
  e.preventDefault();
  $('button[type = "submit"]').prop('disabled', true);
  $('button[type = "submit"]').html('<i class="fa fa-spinner fa-spin"></i>&nbsp;<strong>processing...</strong>');
  var params = $("#jobedit_form").serializeArray();
  $.post(WEB_ROOT + "Jobs/job_update", params, function(data){
    $(".modal-dialog").parent().html(data);
    $('button[type = "submit"]').prop('disabled',false);
    $('button[type = "submit"]').html('<i class="fa fa-pencil-square-o">&nbsp;</i>Update');
    reset_jobs_body(parent);
  });
}

function job_delete(id)
{
  preLoader();
  $.post(WEB_ROOT+"Jobs/job_delete",{"id":id},function (data) {
    loadModal(data);
    closePreLoader();
  });
}

function job_delete_submit(e)
{
  e.preventDefault();
  $('button[type = "submit"]').prop('disabled', true);
  $('button[type = "submit"]').html('<i class="fa fa-spinner fa-spin"></i>&nbsp;<strong>processing...</strong>');
  var params = $("#job_delete_form").serializeArray();
  $.post(WEB_ROOT + "Jobs/job_delete_submit", params, function(data){
    $(".modal-dialog").parent().html(data);
    $('button[type = "submit"]').prop('disabled',false);
    $('button[type = "submit"]').html('<i class="fa fa-pencil-square-o">&nbsp;</i>Update');
    reset_jobs_body(parent);
  });
}

function job_status(id,status,rows,pageno,sortby,sort_order)
{
	$('#status_btn'+id).prop('disabled', true);
  $('#status_btn'+id).html('<i class="fa fa-spinner fa-spin"></i>&nbsp;<strong>processing...</strong>');
  var qStr = {
    "id" : id,
    "status" : status,
    "rows" : rows,
    "pageno" : pageno,
    "sortby" : "id",
    "sort_order" : sort_order,
   };
  $.post(WEB_ROOT+"Jobs/job_status",qStr,function (data) {
  	$('#status_btn'+id).prop('disabled',false);
    $('#status_btn'+id).html('<i class="fa fa-remove">&nbsp;</i>Status');
    jobs_body(rows, pageno, sortby, sort_order);
  });
}

function job_view(id)
{
  preLoader();
  $.post(WEB_ROOT+"Jobs/job_view",{"id":id},function (data) {
    loadModal(data);
    closePreLoader();
  });
}
