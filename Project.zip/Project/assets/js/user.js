
/*Employee*/
function profile_edit(id) {
  preLoader();
  $.post(WEB_ROOT+"User/profile_edit/" + id, function(data) {
    loadModal(data);
    closePreLoader();
  });
}
function profile_update(e) {
  var id = $('#id').val();
  e.preventDefault();
  $('button[type = "submit"]').prop('disabled', true);
  $('button[type = "submit"]').html('<i class="fa fa-spinner fa-spin"></i>&nbsp;<strong>processing...</strong>');
  var str = $("#employee_edit_form").serializeArray();
  $.post(WEB_ROOT+"User/profile_update",str,function (data) {
    $(".modal-dialog").parent().html(data);
    $('button[type = "submit"]').prop('disabled',false);
    $('button[type = "submit"]').html('<i class="fa fa-pencil-square-o">&nbsp;</i>Update');
    user_body(id);
  });
}
function user_body(id) {
  $.post(WEB_ROOT+"User/user_body", { 'id':id }, function (data) {
    $("#user_body").html(data);
  });
}

function user_document_add(id) {
  $.post(WEB_ROOT+"User/user_document_add", {'id':id}, function (data) {
    $("#add_remove").html('');
    $("#user_documents_body").append(data);
  });
}
function user_document_insert(e) {
  e.preventDefault();
  $('button[type = "submit"]').prop('disabled', true);
  $('button[type = "submit"]').html('<i class="fa fa-spinner fa-spin"></i>&nbsp;<strong>processing...</strong>');
  var params = $("#user_document_form").serializeArray();

  var files_array_details = new FormData();
  files_array_details.append('id', $('#id').val());
  files_array_details.append('document_type', $('#document_type').val());
  files_array_details.append('document_list', $('#document_list').prop('files')[0]);
  $.ajax({
    url: WEB_ROOT+'User/user_document_insert',
    dataType: 'text',
    cache: false,
    contentType: false,
    processData: false,
    data: files_array_details,
    type: 'post',
    async: false,
    success: function(data){
      $("#user_documents_body").html(data);
      $('button[type = "submit"]').prop('disabled',false);
      $('button[type = "submit"]').html('<i class="fa fa-plus">&nbsp;</i>Add');
    }
  });
}
function user_document_delete(id,user_id) {
  $.post(WEB_ROOT+"User/user_document_delete", {"id":id,"user_id":user_id}, function (data) {
    $("#user_documents_body").html(data);
  });
}
