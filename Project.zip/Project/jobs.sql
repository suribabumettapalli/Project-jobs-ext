-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 11, 2022 at 08:57 PM
-- Server version: 8.0.28-0ubuntu0.20.04.3
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jobs`
--

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `document_type` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1=Active, 2=Deleted',
  `created_by` tinyint DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `name`, `document_type`, `user_id`, `status`, `created_by`, `created_at`) VALUES
(1, 'document_1_1649524124.JPG', 1, 1, 0, 1, '2022-04-09 22:38:44');

-- --------------------------------------------------------

--
-- Table structure for table `document_type`
--

CREATE TABLE `document_type` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` tinyint DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `document_type`
--

INSERT INTO `document_type` (`id`, `name`, `status`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 'Aadhar(UID)', 1, 1, '2017-11-21 11:29:58', 1, '2019-07-26 11:14:34'),
(2, 'Passport', 1, 1, '2017-11-21 11:30:09', 1, '2017-12-21 12:22:54'),
(3, 'PAN card', 1, 1, '2017-11-21 11:30:26', 1, '2017-12-21 12:22:46'),
(4, 'Driving Licence', 1, 1, '2017-11-21 11:30:39', 1, '2017-12-21 12:22:48'),
(5, 'Others', 1, 1, '2017-11-21 11:30:51', 1, '2017-12-21 12:22:49');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `department` tinyint DEFAULT NULL COMMENT '1=>Development,2=>UI-Design,3=>Testing,4=>Database Analyst',
  `job_desc` text,
  `address` text,
  `pincode` int DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `doj` datetime DEFAULT NULL,
  `remote` tinyint NOT NULL DEFAULT '0' COMMENT '0=>NO,1=>Yes',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1=>enable,2=>disable',
  `created_by` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `department`, `job_desc`, `address`, `pincode`, `company`, `email`, `phone`, `doj`, `remote`, `status`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 'PHP Developer', 3, '6+ experience with PHP Developer in codeigniter', 'Hyderabad', 112233, 'TCS', 'user@sample.com', '9876543210', '2022-05-01 00:00:00', 2, 1, 1, '2022-04-11 20:16:42', 1, '2022-04-11 20:34:48'),
(2, 'Java Developer', 2, '5+ Experience in JAVA', 'Hyderabad', 112233, 'Wipro', 'User12@sample.com', '9876543210', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL),
(3, 'Java Developer', 1, '5+ Experience in JAVA', 'Hyderabad', 112233, 'Cognigent', 'User13@sample.com', '9876543211', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL),
(4, '.net Developer', 2, '6+ Experience', 'Mumbai', 112233, 'Wipro', 'User14@sample.com', '9876543212', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL),
(5, 'Java Developer', 4, '10+ Experience in JAVA', 'Bengalur', 665544, 'CGI', 'User15@sample.com', '9876543213', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL),
(6, 'Java Developer', 2, '5+ Experience in JAVA', 'Hyderabad', 112233, 'BPL', 'User16@sample.com', '9876543214', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL),
(7, 'PHP Developer', 3, '5+ Experience in', 'Vijayawada', 224466, 'Capgemini', 'User17@sample.com', '9876543215', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL),
(8, 'Java Developer', 1, '5+ Experience in JAVA', 'Hyderabad', 112233, 'AAA', 'User18@sample.com', '9876543216', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL),
(9, 'Java Developer', 2, '5+ Experience in JAVA', 'Chenai', 889966, 'Wipro', 'User19@sample.com', '9876543217', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL),
(10, 'PHP Developer', 1, '5+ Experience in PHP', 'Hyderabad', 112233, 'CGI', 'User20@sample.com', '9876543218', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL),
(11, 'Java Developer', 3, '5+ Experience in JAVA', 'Noida', 556644, 'TCS', 'User21@sample.com', '9876543219', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL),
(12, 'Java Developer', 4, '5+ Experience in JAVA', 'Hyderabad', 112233, 'TTT', 'User22@sample.com', '9876543220', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL),
(13, '.NET Developer', 2, '5+ Experience ', 'Hyderabad', 112233, 'Wipro', 'User23@sample.com', '9876543221', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL),
(14, 'Java Developer', 3, '5+ Experience in JAVA', 'Hyderabad', 112233, 'TCS', 'User24@sample.com', '9876543222', '2022-04-30 20:35:03', 0, 1, 1, '2022-04-11 20:35:03', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jobs_extt`
--

CREATE TABLE `jobs_extt` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `gender` tinyint NOT NULL DEFAULT '1' COMMENT '1=>Male,2=>Female',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `role` tinyint DEFAULT NULL COMMENT '1 = super admin, 2 = admin, 3= user',
  `updated_by` int DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `address` text,
  `pincode` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1 = Active, 2= Delete',
  `created_by` int DEFAULT NULL,
  `profile` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `jobs_extt`
--

INSERT INTO `jobs_extt` (`id`, `name`, `gender`, `email`, `password`, `mobile`, `role`, `updated_by`, `updated_at`, `created_at`, `address`, `pincode`, `doj`, `status`, `created_by`, `profile`) VALUES
(1, 'Super Admin', 1, 'superadmin@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 1, NULL, NULL, '2022-03-29 12:28:45', 'Test address\r\nTest Location', '112233', '2022-03-29', 1, 1, NULL),
(3, 'Admin', 1, 'admin@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 2, NULL, NULL, '2022-03-29 21:31:16', 'Test area', '123456', '2022-03-29', 1, 1, '20220329213116_aadhar-card22.JPG'),
(4, 'User1', 1, 'User1@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:31:59', 'Test area', '112233', '2022-03-29', 1, 1, '20220329213159_aadhar-card22.JPG'),
(5, 'User2', 1, 'User2@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:32:32', 'TEst hajsdfgkhj', '114455', '2022-03-16', 1, 1, '20220329213232_aadhar-card22.JPG'),
(6, 'User3', 1, 'User3@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:33:11', 'dsafkjgdsjhf', '225588', '2022-03-29', 1, 1, '20220329213311_aadhar-card22.JPG'),
(7, 'User4', 1, 'User4@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:33:59', 'dssdfds', '123456', '2022-03-16', 1, 1, '20220329213359_aadhar-card22.JPG'),
(8, 'User5', 1, 'User5@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:34:37', 'fdsfds sadfdsf', '558899', '2022-03-22', 1, 1, '20220329213437_aadhar-card22.JPG'),
(9, 'User6', 1, 'User6@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:35:10', 'dsfdsaf adsfds', '112233', '2022-03-21', 1, 1, '20220329213510_aadhar-card22.JPG'),
(10, 'User7', 1, 'User7@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:36:14', 'dfdsa dsafdsf', '112233', '2022-03-21', 1, 1, '20220329213614_aadhar-card22.JPG'),
(11, 'User8', 1, 'User8@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:36:59', 'fdafds adsfsd', '223366', '2022-03-15', 1, 1, '20220329213659_aadhar-card22.JPG'),
(12, 'User9', 1, 'User9@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:37:39', 'fds dsafds ', '223366', '2022-03-21', 1, 1, '20220329213739_aadhar-card22.JPG'),
(13, 'User10', 1, 'User10@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:38:22', 'fdsf sadfdsaf', '223366', '2022-03-22', 1, 1, '20220329213822_aadhar-card22.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `gender` tinyint NOT NULL DEFAULT '1' COMMENT '1=>Male,2=>Female',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `role` tinyint DEFAULT NULL COMMENT '1 = super admin, 2 = admin, 3= user',
  `updated_by` int DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `address` text,
  `pincode` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1 = Active, 2= Delete',
  `created_by` int DEFAULT NULL,
  `profile` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `gender`, `email`, `password`, `mobile`, `role`, `updated_by`, `updated_at`, `created_at`, `address`, `pincode`, `doj`, `status`, `created_by`, `profile`) VALUES
(1, 'Super Admin', 1, 'superadmin@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 1, NULL, NULL, '2022-03-29 12:28:45', 'Test address\r\nTest Location', '112233', '2022-03-29', 1, 1, NULL),
(3, 'Admin', 1, 'admin@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 2, NULL, NULL, '2022-03-29 21:31:16', 'Test area', '123456', '2022-03-29', 1, 1, '20220329213116_aadhar-card22.JPG'),
(4, 'User1', 1, 'User1@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:31:59', 'Test area', '112233', '2022-03-29', 1, 1, '20220329213159_aadhar-card22.JPG'),
(5, 'User2', 1, 'User2@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:32:32', 'TEst hajsdfgkhj', '114455', '2022-03-16', 1, 1, '20220329213232_aadhar-card22.JPG'),
(6, 'User3', 1, 'User3@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:33:11', 'dsafkjgdsjhf', '225588', '2022-03-29', 1, 1, '20220329213311_aadhar-card22.JPG'),
(7, 'User4', 1, 'User4@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:33:59', 'dssdfds', '123456', '2022-03-16', 1, 1, '20220329213359_aadhar-card22.JPG'),
(8, 'User5', 1, 'User5@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:34:37', 'fdsfds sadfdsf', '558899', '2022-03-22', 1, 1, '20220329213437_aadhar-card22.JPG'),
(9, 'User6', 1, 'User6@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:35:10', 'dsfdsaf adsfds', '112233', '2022-03-21', 1, 1, '20220329213510_aadhar-card22.JPG'),
(10, 'User7', 1, 'User7@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:36:14', 'dfdsa dsafdsf', '112233', '2022-03-21', 1, 1, '20220329213614_aadhar-card22.JPG'),
(11, 'User8', 1, 'User8@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:36:59', 'fdafds adsfsd', '223366', '2022-03-15', 1, 1, '20220329213659_aadhar-card22.JPG'),
(12, 'User9', 1, 'User9@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:37:39', 'fds dsafds ', '223366', '2022-03-21', 1, 1, '20220329213739_aadhar-card22.JPG'),
(13, 'User10', 1, 'User10@sample.com', '25d55ad283aa400af464c76d713c07ad', '9876543210', 3, NULL, NULL, '2022-03-29 21:38:22', 'fdsf sadfdsaf', '223366', '2022-03-22', 1, 1, '20220329213822_aadhar-card22.JPG');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_type`
--
ALTER TABLE `document_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs_extt`
--
ALTER TABLE `jobs_extt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `document_type`
--
ALTER TABLE `document_type`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `jobs_extt`
--
ALTER TABLE `jobs_extt`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
