<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
@include_once("Common.php");
class User extends Common {
  public function __construct() {
    parent::__construct();
    $this ->load->model('User_model');
    $this->load->library('session');
    $this->load->helper('security');
    $this->load->library('form_validation');
  }

  /*
  User profile information
  */
  public function index()
  {
    $user = $this->session->userdata('emp');
    if(isset($user['id'])){
      $this->profile();
    }else{
      redirect(SITE_URL.'login','refresh');
    }
  }

  /*
  User profile information
  */
  public function profile()
  {
    $emp = $this->session->userdata('emp');
    $data['emp'] = $this->User_model->getUserdata($emp['id']);
    $data['documents'] = $this->User_model->getUserDocuments($emp['id']);
    $data['document_types'] = $this->Common_model->getDocumentTypes();

    if($data['emp']){
      $this->load->view('header');
      $this->load->view("profile",$data);
      $this->load->view('footer');
    }
    else {
      print "No details found with this name";
    }
  }

  /*
  User profile information
  */
  public function user_body()
  {
    $data['emp'] = $this->User_model->getUserdata($_POST['id']);
    $this->load->view("profile",$data);
  }

  /*
  User profile edit form
  */
  public function profile_edit($user_id)
  {
    $data['emp'] = $this->User_model->getUserdata($user_id);
    $this->load->view('user_edit',$data);
  }

  /*
  User profile update with required validation
  */
  public function profile_update()
  {
    $this->load->library('form_validation');
    $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
    $this->form_validation->set_rules('name', 'Name', 'required');
    $this->form_validation->set_rules('mobile', 'Mobile', 'required|numeric|exact_length[10]|integer|is_natural');
    if($this->form_validation->run() == FALSE) {
      $data['emp'] = $this->User_model->getUserdata($_POST['id']);
      $this->load->view("user_edit",$data);
    }
    else {
      $data = array(
        'name' => $_POST['name'],
        'mobile' => $_POST['mobile'],
        'updated_at'=>date('Y-m-d H:i:s'),
        'updated_by'=>$_SESSION['emp']['id']
      );
      if($this->User_model->user_update($data,$_POST['id'])){
        $alert = array('color' => 'success', 'msg' => "Profile Updated Successfully.");
      }
      else {
        $alert = array('color' => 'danger', 'msg' => "Profile Update Failed..");
      }
      $this->load->view("alert_modal", $alert);
    }
  }

  /*
  User logout(session destroy)
  */
  public function logout()
  {
    $this->session->unset_userdata('emp');
    $this->session->sess_destroy();
    redirect(SITE_URL.'Login', 'refresh');
  }

  /*
  User document add form
  */
  public function user_document_add()
  {
    $data['emp']['id'] = $this->input->post('id');
    $data['document_types'] = $this->Common_model->getDocumentTypes();
    $this->load->view('user_document_add', $data);
  }

  /*
  User document insert
  */
  public function user_document_insert()
  {
    $data = $_POST;
    // Documents
    if(isset($_FILES['document_list'])) {
      if (isset($_FILES['document_list']) and $_FILES['document_list']['error'] == 0) {
        $config['upload_path'] = DOCUMENT_ROOT . 'assets/files';
        $config['allowed_types'] = 'pdf|jpeg|png|jpg';
        $config['max_size'] = 2048;
        $config['file_name'] = 'document_'. $data['id'] . '_' . time();
        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $data['document_list'] = "";
        if ($this->upload->do_upload('document_list')) {
          $upload_data = $this->upload->data();
          $file = $upload_data['file_name'];
          chmod('assets/files/' . $file, 0777);
          $data['document_list'] = $file;
          //
          $documents = array( "user_id" => $data['id'], "document_type" => $data['document_type'], "name" => $data['document_list'], 'created_at' => date('Y-m-d H:i:s',time()), 'created_by' => $_SESSION['emp']['id']);
          $this->User_model->user_document_insert($documents);

          $data['msg'] = "Document uploaded Successfully.";
          $data['color'] = "success";
        }
        else {
          $data['value']['error'] = $this->upload->display_errors();
          $data['msg'] = "Document uploaded Failed.";
          $data['color'] = "danger";
        }
      }
    }
    else {
      $data['msg'] = "Documents Not uploaded...";
      $data['color'] = "warning";
    }

    $data['emp']['id'] = $data['id'];
    $data['documents'] = $this->User_model->getUserDocuments($data['id']);
    $data['document_types'] = $this->Common_model->getDocumentTypes();
    $this->load->view('user_view_documents', $data);
  }

  /*
  User document delete
  */
  public function user_document_delete()
  {
    // delete document in table
    $this->User_model->user_document_delete($this->input->post('id'));

    $data['documents'] = $this->User_model->getUserDocuments($this->input->post('user_id'));
    $data['document_types'] = $this->Common_model->getDocumentTypes();
    $data['emp']['id'] = $this->input->post('user_id');

    if(!empty($data['documents'])) { $data['documents'] = $data['documents']; }
    else { $data['documents'] = ""; }

    $data['msg'] = "Document Delete Successfully.";
    $data['color'] = "danger";

    $this->load->view('user_view_documents', $data);
  }
}
?>