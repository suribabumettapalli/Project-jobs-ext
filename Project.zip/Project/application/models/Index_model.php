<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Index_model extends CI_Model {
	public function __construct() 
  {
		$this->load->database();
	}

  /*
  Login user credentials check with database and return user data.
  */
  public function login($user_name, $password) 
  {
    $this->db->where('email', $user_name);
    $this->db->where('password', $password);
    $this->db->where('status', 1);
    $query = $this->db->get('users');
    if ($query->num_rows() == 1) {
      $result = $query->row_array();
      return $result;
    }
    return FALSE;
  }
}
