      <div class="footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-4 col-sm-4 col-xs-4">
              <div class="fo-item">POWERED BY(SURI BABU)</div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-4">
              <div class="fo-item">&copy;&nbsp;Jobs <?php print date('Y');?></div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-4">
              <div class="fo-item pull-right">
                <small style="color: #666666;">Version(1.01)</small>
              </div>
          </div>
        </div>
      </div>
    </div>
	</body>
</html>

<style type="text/css">
.footer {
  background-color: #333333;
  bottom: 0;
  left: 0;
  position: fixed;
  right: 0;
  text-align: center;
}
.footer .fo-item {
  color: hsl(0, 0%, 100%);
  padding: 10px;
}
</style>