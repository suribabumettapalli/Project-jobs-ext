<?php 
if($this->session->flashdata('flag')){
  $this->load->view('alert',$this->session->flashdata('flag'));
}
?>
<div id="user_body">
  <div class="main-body">
    <div class="row gutters-sm">
      <div class="col-md-9 col-sm-12 col-xs-12">
        <div class="row">
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="#">
              <div class="#">
                <h3>Personal details</h3>
              </div>
              <table class="table">
                <tbody>                    
                  <tr>
                    <td>Name</td>
                    <td>:</td>
                    <td><?php if(isset($emp['name'])) print $emp['name'];?></td>
                  </tr>                    
                  <tr>
                    <td>Mail</td>
                    <td>:</td>
                    <td class="email"><?php if(isset($emp['email'])) print $emp['email']; ?></td>
                  </tr>
                  <tr>
                    <td>Mobile</td>
                    <td>:</td>
                    <td><?php if(isset($emp['mobile'])) print $emp['mobile']; ?></td>
                  </tr>
                  <tr>
                    <td>Role</td>
                    <td>:</td>
                    <td>
                      <?php if(isset($emp['role'])){
                        switch ($emp['role']){
                          case '1': print "Super Admin";break;
                          case '2': print "Admin";break;
                          case '3': print "User";break;
                          default:'';break;
                        }
                      } ?>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="BR-top"></div>
          <div id="user_documents_body" class="padbtm">
            <div>
              <div class="cvtables">
                <div id="user_documents_body" class="padbtm">
                  <?php $this->load->view('user_view_documents');?>
                </div>
              </div>             
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>