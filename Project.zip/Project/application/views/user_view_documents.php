<div class="cv-title">
  <h3>Documents&nbsp;:</h3>
</div>
<div class="row">
<?php
$document_count = 0;
if(isset($color) && isset($msg)) {
  ?>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div id="alert_data" class="alert alert-<?php ($color) ? print $color : print "info";?> alert-dismissible">
        <?php if(isset($msg)) print $msg;?>  <?php if(isset($error)) print $error;?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>            
    </div>
  </div>
  <?php    
}
if(!empty($documents)) {
  $document_count = count($documents);
  $error = isset($value['error']) ? $value['error'] : "";
  foreach ($documents as $doc_key => $doc_value) {
    $path = 'assets/files/';
    if (is_file(DOCUMENT_ROOT . $path . $doc_value['name'])) {
      // Document Extention Checking
      $ext = substr($doc_value['name'], -4);
      if($ext == ".jpg" || $ext == "jpeg" || $ext == ".png" || $ext == ".JPG" || $ext == "JPEG" || $ext == ".PNG") {
        ?>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div align="center">            
            <div class="profile-doc-img">
              <a href="<?php print WEB_ROOT . $path . $doc_value['name']; ?>" target=_blank>
                <img src="<?php print WEB_ROOT . $path . $doc_value['name']; ?>" title="View image">
              </a>               
            </div>  
            <h5><?php print isset($document_types[$doc_value['document_type']]['name']) ? $document_types[$doc_value['document_type']]['name'] : "&nbsp;" ;?></h5>  
            <div class="form-group">
              <button type="button" class="btn btn-xs btn-danger" onclick="user_document_delete(<?php print $doc_value['id'] ;?>,<?php print $doc_value['user_id'] ;?>)"><i class="fa fa-trash"></i></button>
            </div>       
          </div>
        </div>
        <?php
      }
      else if($ext == ".pdf" || $ext == ".PDF") {
        $pdf_path = 'assets/images/pdf.png';
        ?>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div align="center">            
            <div class="profile-doc-img">
              <a target="_blank" href="<?php print WEB_ROOT . $path . $doc_value['name']; ?>" >
                <img src="<?php print WEB_ROOT . $pdf_path; ?>" alt="pdf">
              </a>                
            </div> 
            <h5><?php print isset($document_types[$doc_value['document_type']]['name']) ? $document_types[$doc_value['document_type']]['name'] : "&nbsp;" ;?></h5>  
            <div class="form-group">
              <button type="button" class="btn btn-danger btn-xs" onclick="user_document_delete(<?php print $doc_value['id'] ;?>,<?php print $doc_value['user_id'] ;?>)" ><i class="fa fa fa-trash" aria-hidden="true"></i></button>
            </div>       
          </div>
        </div>
        <?php
      }
    }
    else {
      ?><div class="alert alert-warning"><?php print _("Document Files Not Found");?></div><?php
    }              
    ?>
    <div id="user_documents_update"></div>
    <?php
  }
  ?>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="form-group" id="add_remove">
        <a class="btn btn-success btn-sm" onclick="user_document_add(<?php print $emp['id'] ;?>)">
          <i class="glyphicon glyphicon-plus"></i>&nbsp;&nbsp;Add Document
        </a>
      </div>          
    </div>
  </div>
  <?php
}
else {
  ?>
  <div class="cv-title">
    <div class="form-group" id="add_remove">
      <a class="btn btn-success btn-sm" onclick="user_document_add(<?php print $emp['id'] ;?>)">
        <i class="glyphicon glyphicon-plus"></i>&nbsp;&nbsp;Add Documents
      </a>
    </div>    
  </div>
  <div id="user_documents_update"></div>
  <?php
  
}
?>
</div>
<style type="text/css">
  .profile-doc-img {
    width: 100%;
    height: 150px;
    padding: 5px;
  }
  .profile-doc-img img {
    max-width: 100%;
    max-height: 100%;
  }
</style>
<script type="text/javascript">
  $(document).ready(function(){
    setTimeout(function(){
      $('#alert_data').fadeOut();
    },3000);
  });
</script>