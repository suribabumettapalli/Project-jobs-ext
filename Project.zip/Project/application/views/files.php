<br>
<br>
<?php 
	if($this->session->flashdata('success')) {
		print '<div class="alert alert-success alert-dismissible" role="alert">
				  	' . $this->session->flashdata('success') . '.
				  	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    	<span aria-hidden="true">&times;</span>
				  	</button>
				</div>';
	}
	if($this->session->flashdata('error')) {
		print '<div class="alert alert-danger alert-dismissible" role="alert">
				  	' . $this->session->flashdata('error') . '.
				  	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    	<span aria-hidden="true">&times;</span>
				  	</button>
				</div>';
	}
?>
<br>
<button class="btn btn-sm btn-primary file_add">Add File</button>
<br>
<br>
<table class="table table-bordered table-responsive">
	<thead>
		<tr>
			<th>S.No</th>
			<th>File</th>
			<th>Uploaded By</th>
		</tr>
	</thead>
	<tbody>
		<?php
			$index = 1;
			foreach($files as $file) { ?>
				<tr>
					<td><?php print $index++; ?></td>
					<td><a target='_blank' href="<?php echo base_url(); ?>assets/uploads/<?php print $file["name"]; ?>"><?php print $file["name"]; ?></a></td>
					<td><?php print $file["user_name"]; ?></td>
				</tr>
			<?php }
		?>
	</tbody>
</table>
<!-- MODAL -->
<div class="modal" tabindex="-1" role="dialog" id="file_add_modal">
  	<div class="modal-dialog" role="document">
    	<div class="modal-content">
		    <div class="modal-header">
	        	<h5 class="modal-title">File Upload</h5>
	        	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		        	<span aria-hidden="true">&times;</span>
		        </button>
		    </div>
	      	<div class="modal-body">
	        	<div class="center-block well">
					<form method="post" action="<?php print base_url(); ?>index.php/sample/file_upload" enctype="multipart/form-data">
					  <label>Select File to upload:</label>
					  <input type="file" name="userfile" id="userfile">
					  <br>
					  <input type="submit" value="Upload Image" name="submit">
					</form>
				</div>
	      	</div>
      		<div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      		</div>
    	</div>
  	</div>
</div>
<!-- MODAL -->
<script>
	$(document).ready(function() {
		$("body").on("click", ".file_add", function() {
			$("#file_add_modal").modal("show");
		});
	});
</script>