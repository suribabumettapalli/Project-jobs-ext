<section>
  <div class="row">
    <div class="col-md-12">
      <div align="center">
      <h1><u>Dashboard</u></h1>
      </div>
    </div>
    <div>&nbsp;</div>
    <div class="col-md-4 col-md-offset-4">
      <div class="card">
        <div class="card-body">
          <p class="text-uppercase small mb-2"><strong>Total Jobs</strong></p>
          <h5 class="font-weight-bold mb-0">
            <a href="<?php print WEB_ROOT;?>Jobs"><?php print $total_jobs; ?></a>
          </h5>
          <hr>
        </div>
      </div>
    </div>
  </div>
</section>