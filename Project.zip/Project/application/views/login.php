<!DOCTYPE html>
<html>
<head>
	<title>Access Control</title>
	<link rel="stylesheet" type="text/css" href="<?php print WEB_ROOT; ?>assets/css/bootstrap.css">
	<script src="<?php print WEB_ROOT; ?>assets/js/jquery.js"></script>
	<script src="<?php print WEB_ROOT; ?>assets/js/bootstrap.js"></script>
</head>
<body>
	<div class="container">
		<div class="row">
      <div class="col-md-offset-3 col-md-6">
  			<h2 style="text-align: center;">Login</h2>
        <div class="well">
          <form method="post" action="<?php print WEB_ROOT;?>Login">
            <div class="form-group">
              <label for="email">Email address</label>
              <input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="<?php print set_value('email'); ?>">
              <span class="text-danger"><?php print form_error('email'); ?></span>
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" class="form-control" id="password" name="password" placeholder="Password" value="<?php print set_value('password'); ?>">
              <span class="text-danger"><?php print form_error('password'); ?></span>
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
          </form>
        </div>
      </div>
		</div>
	</div>
</body>
</html>