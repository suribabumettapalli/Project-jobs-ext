<?php
$arrow = ($params['sort_order']=='desc')?'&nbsp;<i class="fa fa-caret-down"></i>':'&nbsp;<i class="fa fa-caret-up"></i>';
$sort_order_alt = ($params['sort_order']=='desc')? "asc":"desc";
$sortby = $params['sortby'];
$rows = $params['rows'];
$tRecords = $params['tRecords'];
$sort_order = $params['sort_order'];
$pageno = $params['pageno'];
$name = (isset($_POST['name'])) ? $_POST['name'] : "" ;
$keywords = (isset($_POST['keywords'])) ? $_POST['keywords'] : "" ;
$s_department = (isset($_POST['s_department'])) ? $_POST['s_department'] : "" ;
$total_pages = ceil($tRecords/$rows);
$i = $params['rows']*($params['pageno'] - 1) + 1;
?>
<div class="formTab">
  <form class="form-inline" method="post">
    <div class="pull-left">
      <input type="hidden" id="type" name="type"  class="form-control">
      <div class="form-group">
        <input class="form-control input-sm" type="text" id="keywords" name="keywords" placeholder="Search" value="<?php print $keywords;?>" >
      </div>
      <div class="form-group">
        <label>Department:</label>
        <select id="s_department" name="s_department" class="form-control input-sm" onchange="jobs_body('<?php print $rows;?>', '1', '<?php print $sortby;?>', '<?php print $sort_order;?>')" >
          <option value=""> All</option>
          <option <?php if($s_department == 1) print "selected='selected'"; ?> value="1"> Development</option>
          <option <?php if($s_department == 2) print "selected='selected'"; ?> value="2"> UI-Design</option>
          <option <?php if($s_department == 3) print "selected='selected'"; ?> value="3"> Testing</option>
          <option <?php if($s_department == 4) print "selected='selected'"; ?> value="4"> Database Analysis</option>
        </select>
      </div>
      <div class="form-group">
        <a class="btn btn-info btn-sm" id="search" onclick="jobs_body('<?php print $rows;?>', '1', '<?php print $sortby;?>', '<?php print $sort_order;?>')" title="search">
          <i  class="fa fa-search"></i>
        </a>
        <a class="btn btn-info btn-sm" onclick="reset_jobs_body()" title="Reset">
          <i  class="fa fa-refresh"></i>
        </a>
        <span class="cgd-records-count"><?php print '(' . $tRecords . ' ' . _("Records") .')';?></span>&nbsp;
      </div>
    </div>
    <div class="pull-right">
      <?php if($_SESSION['emp']['role'] == 1 || $_SESSION['emp']['role'] == 2) { ?>
        <div class="form-group">
          <a class="btn btn-sm btn-success" href="javascript:job_add(this)">
            <i class="fa fa-plus">&nbsp;</i>Add Job
          </a>
        </div>
      <?php } ?>
      <div class="form-group">
        <div id="pager-show">
          <?php
          if($jobs) {
            ?>
            <div class="form-group">
              <select class="form-control input-sm" name="rows" onchange="jobs_body(this.value, '1', '<?php print $sortby;?>', '<?php print $sort_order;?>')" >
                <option value="10" <?php if ($rows == 10) print 'selected="selected"';?> >10 <?php print _("Records");?></option>
                <option value="20" <?php if ($rows == 20) print 'selected="selected"';?> >20 <?php print _("Records");?></option>
                <option value="50" <?php if ($rows == 50) print 'selected="selected"';?> >50 <?php print _("Records");?></option>
                <option value="100" <?php if ($rows == 100) print 'selected="selected"';?> >100 <?php print _("Records");?></option>
                <option value="1000" <?php if ($rows == 1000) print 'selected="selected"';?> >1000 <?php print _("Records");?></option>
              </select>
            </div>
              <div class="form-group">
                <div class="input-group">
                  <span class="input-group-btn">
                    <?php
                    if ($pageno == 1) {
                      print '<button type="button" class="btn btn-default btn-sm disabled"><i class="fa fa-backward"></i></button>';
                      print '<button type="button" class="btn btn-default btn-sm disabled"><i class="fa fa-chevron-left"></i></button>';
                    }
                    else {
                      ?>
                      <a class="btn btn-default btn-sm" href="javascript:void(0);" onclick="jobs_body('<?php print $rows;?>', '1', '<?php print $sortby;?>', '<?php print $sort_order;?>')">
                        <i class="fa fa-backward"></i>
                      </a>
                      <a class="btn btn-default btn-sm" href="javascript:void(0);" onclick="jobs_body('<?php print $rows;?>', '<?php print $pageno-1;?>', '<?php print $sortby;?>', '<?php print $sort_order;?>')" >
                        <i class="fa fa-chevron-left"></i>
                      </a>
                      <?php
                    }
                    ?>
                  </span>
                  <select class="form-control input-sm" name="rows" onchange="jobs_body('<?php print $rows;?>', this.value, '<?php print $sortby;?>', '<?php print $sort_order;?>')" >
                    <?php
                    for ($pg=1; $pg <= $total_pages; $pg++) {
                      ?>
                      <option value="<?php print $pg?>" <?php if ($pg == $pageno) print 'selected="selected"';?> >
                        <?php print $pg . '/' . $total_pages;?>
                      </option>
                      <?php
                    }
                    ?>
                  </select>
                  <span class="input-group-btn">
                    <?php
                    if ($pageno == $total_pages) {
                      print '<button type="button" class="btn btn-default btn-sm disabled"><i class="fa fa-chevron-right"></i></button>';
                      print '<button type="button" class="btn btn-default btn-sm disabled"><i class="fa fa-forward"></i></button>';
                    }
                    else {
                      ?>
                      <a class="btn btn-default btn-sm" href="javascript:void(0);" onclick="jobs_body('<?php print $rows;?>', '<?php print $pageno+1;?>', '<?php print $sortby;?>', '<?php print $sort_order;?>')">
                        <i class="fa fa-chevron-right"></i>
                      </a>
                      <a class="btn btn-default btn-sm" href="javascript:void(0);" onclick="jobs_body('<?php print $rows;?>', '<?php print $total_pages;?>', '<?php print $sortby;?>', '<?php print $sort_order;?>')" >
                        <i class="fa fa-forward"></i>
                      </a>
                      <?php
                    }
                    ?>
                  </span>
                </div>
              </div>
            <?php
          }
          ?>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
  </form>
</div>
<div id="bisiness_types_body">
  <div class="table-responsive">
    <?php if ($jobs) { ?>
      <table id ="job_table" class="table fixed-head table-bordered table-hover table-condensed table-striped">
        <thead>
          <tr class="bg-info">
            <th class="text-center" width="1%">S.No</th>
            <th>
              <?php if ($sortby == 'company')  print $arrow; ?>
              <a href="javascript:void(0)" onclick="jobs_body('<?php print $rows;?>', '1', 'company', '<?php print $sort_order_alt;?>')">Company
              </a>
            </th>
            <th>
              <?php if ($sortby == 'title')  print $arrow; ?>
              <a href="javascript:void(0)" onclick="jobs_body('<?php print $rows;?>', '1', 'title', '<?php print $sort_order_alt;?>')">Title
              </a>
            </th>
            <th>
              <?php if ($sortby == 'department')  print $arrow; ?>
              <a href="javascript:void(0)" onclick="jobs_body('<?php print $rows;?>', '1', 'department', '<?php print $sort_order_alt;?>')">Department
              </a>
            </th>
            <th>
              <?php if ($sortby == 'mobile')  print $arrow; ?>
              <a href="javascript:void(0)" onclick="jobs_body('<?php print $rows;?>', '1', 'mobile', '<?php print $sort_order_alt;?>')">Mobile
              </a>
            </th>
            <th>
              <?php if ($sortby == 'email')  print $arrow; ?>
              <a href="javascript:void(0)" onclick="jobs_body('<?php print $rows;?>', '1', 'email', '<?php print $sort_order_alt;?>')">Email
              </a>
            </th>
            <th><?php print _("Actions")?></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($jobs as $id => $job) { ?>
            <tr id="job_tr_<?php print $job['id'];?>">
              <td class="text-center"><?php print $i++;?></td>
              <td><?php print $job['company'];?></td>
              <td><?php print $job['title'];?></td>
              <td>
                <?php
                  switch ($job['department']){
                    case '1': print "Development";break;
                    case '2': print "UI-design";break;
                    case '3': print "Testing";break;
                    case '4': print "Database Analysis";break;
                    default:'';break;
                  }
                ?>
              </td>
              <td><?php print $job['phone'];?></td>
              <td><?php print $job['email'];?></td>
              <td>
                <?php if($_SESSION['emp']['role'] == 1 || $_SESSION['emp']['role'] == 2) { 
                    ?>
                    <button class="btn btn-xs btn-danger" id="del_btn<?php print $job['id'];?>" onclick="job_delete(<?php print $job['id'];?>)"><span class="fa fa-trash">&nbsp;</span>Delete</button>
                    <?php 
                } 
                if($_SESSION['emp']['role'] == 1) { ?>
                  <button class="btn btn-xs btn-primary" onclick="job_edit(<?php print $job['id'];?>,<?php print $rows;?>,<?php print $pageno ;?>,'<?php print $sortby ;?>','<?php print $sort_order ;?>')"><span class="fa fa-edit">&nbsp;</span>Edit</button>
                  <button class="btn btn-xs btn-info" onclick="job_view(<?php print $job['id'];?>)"><span class="fa fa-eye">&nbsp;</span>View</button>

                  <?php if($job['status'] == 1){ ?>
                    <button type="button" class="btn btn-xs btn-warning" id="status_btn<?php print $job['id'];?>" onclick="job_status(<?php print $job['id'];?>,<?php print $job['status'];?>,<?php print $rows;?>,<?php print $pageno ;?>,'<?php print $sortby ;?>','<?php print $sort_order ;?>')"><span class="fa fa-remove">&nbsp;</span>Disable</button>
                  <?php } else{ ?>
                    <button type="button" class="btn btn-xs btn-success" id="status_btn<?php print $job['id'];?>" onclick="job_status(<?php print $job['id'];?>,<?php print $job['status'];?>,<?php print $rows;?>,<?php print $pageno ;?>,'<?php print $sortby ;?>','<?php print $sort_order ;?>')"><span class="fa fa-check">&nbsp;</span>Enable</button>
                  <?php } 
                } ?>
              </td>
            </tr>
            <?php
          } ?>
        </tbody>
      </table>
  </div>
  <?php } else { ?>
  <div class="alert alert-warning"><?php print _("No Records Found");?></div><?php
  }?>
</div>