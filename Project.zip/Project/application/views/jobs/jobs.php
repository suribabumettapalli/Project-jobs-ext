<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      <div id="jobs_body" class="marTop">
        <?php $this->load->view('jobs/jobs_body') ?>
      </div>
    </div>
  </div>
</div>
<div class="adjust-footer">&nbsp;</div>