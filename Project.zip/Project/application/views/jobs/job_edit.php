<div class="modal-dialog modal-md meghaModal">
  <div class="modal-content">
    <div class="modal-header mgHeader">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      <h4 class="modal-title" id="myModalLabel">Edit Job</h4>
    </div>
    <form name="jobedit_form" id="jobedit_form" method="post" onsubmit="job_update(event)">
      <div class="modal-body">
        <div class="form-group">
          <label class="control-label">Company&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <input type="hidden" name="id" id="id" value="<?php print $job['id'];?>">
          <input type="text" id="company" name="company" class="form-control input-sm" placeholder="Name" value="<?php print $job['company'];?>" />
          <small class="text-danger"><?php print form_error('company');?></small>
        </div>

        <div class="form-group">
          <label class="control-label">Title&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <input type="text" id="title" name="title" class="form-control input-sm" placeholder="Name" value="<?php print $job['title'];?>" />
          <small class="text-danger"><?php print form_error('title');?></small>
        </div>

        <div class="form-group">
          <label class="control-label">Department&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <select class="form-control input-sm" name="department" id="department">
            <option value="">Select</option>
            <option value="1" <?php if($job['department'] == 1 ) print "selected='selected'"; ?>>Developent</option>
            <option value="2" <?php if($job['department'] == 2 ) print "selected='selected'"; ?> >UI-Design</option>
            <option value="3" <?php if($job['department'] == 3 ) print "selected='selected'"; ?> >Testing</option>
            <option value="4" <?php if($job['department'] == 4 ) print "selected='selected'"; ?> >Database Analysis</option>
          </select>
          <small class="text-danger"><?php print form_error('department');?></small>
        </div>

        <div class="form-group">
          <label class="control-label">Job Description &nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <textarea calss="form-control input-sm" name="job_desc" id="job_desc" rows="2" cols="60"><?php print $job['job_desc'];?></textarea>
          <small class="text-danger"><?php print form_error('job_desc');?></small>
        </div>

        <div class="form-group">
          <label class="control-label">Remote&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="remote" id="remote" value="1" <?php if($job['remote'] == 1 ) print "checked"; ?> >
            <label class="form-check-label" for="1">
              Yes
            </label>
            <span>&nbsp;&nbsp;</span>
            <input class="form-check-input" type="radio" name="remote" id="remote" value="2" <?php if($job['remote'] == 2 ) print "checked"; ?>>
            <label class="form-check-label" for="2">
              No
            </label>
            <small class="text-danger"><?php print form_error('remote');?></small>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label">Email&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <input type="text" id="email" name="email" class="form-control input-sm" placeholder="Email" value="<?php print $job['email'];?>" />
          <small class="text-danger"><?php print form_error('email');?></small>
        </div>

        <div class="form-group">
          <label class="control-label">Mobile&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <input type="text" id="phone" name="phone" class="form-control input-sm" placeholder="Mobile" value="<?php print $job['phone'];?>" />
          <small class="text-danger"><?php print form_error('phone');?></small>
        </div>


        <div class="form-group">
          <label class="control-label">Address&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <textarea calss="form-control input-sm" name="address" id="address" rows="2" cols="60"><?php print $job['address'];?></textarea>
          <small class="text-danger"><?php print form_error('address');?></small>
        </div>

         <div class="form-group">
          <label class="control-label">PIN code&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <input type="text" id="pincode" name="pincode" class="form-control input-sm" placeholder="PIN code" value="<?php print $job['pincode'];?>" />
          <small class="text-danger"><?php print form_error('pincode');?></small>
        </div>

        <div class="form-group">
          <label class="control-label">Date Of Expected Join&nbsp;:&nbsp;<span class="text-danger">*</span></label>
          <div class="input-group">
            <input type="text" id="doj" name="doj" class="form-control input-sm" placeholder="DD-MM-YYYY" value="<?php print date("d-m-Y", strtotime($job['doj']));?>" />
            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
          </div>
          <small class="text-danger"><?php print form_error('doj');?></small>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-sm btn-success"><i class="fa fa-check" aria-hidden="true">&nbsp;</i><?php print _("Update");?></button>
        <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"><i class="fa fa-close" aria-hidden="true">&nbsp;</i><?php print _("Close");?></button>
      </div>
    </form>
  </div>
</div>

<script type="text/javascript">
  $('#doj').datepicker({format: 'dd-mm-yyyy',startDate: 'today',autoclose: true}).on('changeDate', function(ev) {
    $(this).datepicker('hide');
  });
</script>