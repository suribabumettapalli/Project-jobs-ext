<div class="modal-dialog modal-md meghaModal">
  <div class="modal-content">
    <div class="modal-header mgHeader">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      <h4 class="modal-title" id="myModalLabel">Job Details</h4>
    </div>
      <div class="modal-body">
      <table class="table">
        <tbody>                    
          <tr>
            <td>Company</td>
            <td>:</td>
            <td><?php if(isset($job['company'])) print $job['company'];?></td>
          </tr>
          <tr>
            <td>Job title</td>
            <td>:</td>
            <td><?php if(isset($job['title'])) print $job['title'];?></td>
          </tr>                    
          <tr>
            <td>Department</td>
            <td>:</td>
            <td>
              <?php if(isset($job['department'])){
                switch ($job['department']){
                  case '1': print "Development";break;
                  case '2': print "UI-Design";break;
                  case '3': print "Testing";break;
                  case '4': print "Database Analysis";break;
                  default:'';break;
                }
              } ?>
            </td>
          </tr>
          <tr>
            <td>Job description</td>
            <td>:</td>
            <td><?php if(isset($job['job_desc'])) print $job['job_desc']; ?></td>
          </tr>
          <tr>
            <td>Mail</td>
            <td>:</td>
            <td class="email"><?php if(isset($job['email'])) print $job['email']; ?></td>
          </tr>
          <tr>
            <td>Mobile</td>
            <td>:</td>
            <td><?php if(isset($job['phone'])) print $job['phone']; ?></td>
          </tr>
          <tr>
            <td>Remote</td>
            <td>:</td>
            <td><?php if(isset($job['gender']) && $job['gender']==1 ) print "Available"; else print "Not Available"; ?></td>
          </tr>
          <tr>
            <td>Date Of Expected Join</td>
            <td>:</td>
            <td><?php if(isset($job['doj'])) print date("d-m-Y", strtotime($job['doj'])); ?></td>
          </tr>
          <tr>
            <td>Address</td>
            <td>:</td>
            <td><?php if(isset($job['address'])) print $job['address']; ?></td>
          </tr>
          <tr>
            <td>PIN code</td>
            <td>:</td>
            <td><?php if(isset($job['pincode'])) print $job['pincode']; ?></td>
          </tr>

        </tbody>
      </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"><i class="fa fa-close" aria-hidden="true">&nbsp;</i>Close</button>
      </div>
  </div>
</div>