<div class="modal-dialog modal-md meghaModal">
  <div class="modal-content">
    <div class="modal-header mgHeader">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      <h4 class="modal-title" id="myModalLabel">Delete Job</h4>
    </div>
    <form name="job_delete_form" id="job_delete_form" method="post" onsubmit="job_delete_submit(event)">
      <div class="modal-body">
      <input type="hidden" id="id" name="id" value="<?php print $job['id']; ?>" />
      <table class="table">
        <tbody>                    
          <tr>
            <td>Company</td>
            <td>:</td>
            <td><?php if(isset($job['company'])) print $job['company'];?></td>
          </tr>
          <tr>
            <td>Title</td>
            <td>:</td>
            <td><?php if(isset($job['title'])) print $job['title'];?></td>
          </tr>                    
          <tr>
            <td>Department</td>
            <td>:</td>
            <td>
              <?php if(isset($job['department'])){
                switch ($job['department']){
                  case '1': print "Developer";break;
                  case '2': print "UI_Designer";break;
                  case '3': print "Testing";break;
                  case '4': print "Database Analysis";break;
                  default:'';break;
                }
              } ?>
            </td>
          </tr>
          <tr>
            <td>Mail</td>
            <td>:</td>
            <td class="email"><?php if(isset($job['email'])) print $job['email']; ?></td>
          </tr>
          <tr>
            <td>Mobile</td>
            <td>:</td>
            <td><?php if(isset($job['phone'])) print $job['phone']; ?></td>
          </tr>
        </tbody>
      </table>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-sm btn-warning"><i class="fa fa-trash" aria-hidden="true">&nbsp;</i>Delete</button>
        <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal"><i class="fa fa-close" aria-hidden="true">&nbsp;</i>Close</button>
      </div>
    </form>
  </div>
</div>